<?php
	global $conn;
	$conn = mysqli_connect("localhost","root","","pwd");
?>